#ifdef __APPLE__
#  include <GL/glew.h>
#  include <GL/freeglut.h>
#  include <OpenGL/glext.h>
#else
#  include <GL/glew.h>
#  include <GL/freeglut.h>
//#  include <GL/glext.h>
#pragma comment(lib, "glew32.lib") 
#endif

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <stdio.h>
#include <string.h>

using namespace std;

int main()
{
ifstream archivo("Datos.txt"); //Nombre del archivo a trabajar
char texto[400][400]; //Arreglo para almacenar los caracteres del archivo
int salto=0; //Contador para identificar el numero de lineas
while(!archivo.eof()){ //Guardando el contenido del archivo en el arreglo linea.
	archivo.getline(texto[salto],400);
	cout<<"su tamano es "<<strlen(texto[salto])<<" es "<<texto[salto]<<endl; //Mostrando el contenido
	salto++; //Avanzando a la siguiente fila.
}

cout<<"numero de saltos: "<<salto;

double numero[400];
char nuevo[400][400];
int fila=0; 
int col=0;
int total=0;
char *cambio; //Para realizar la conversion de la matriz char a arreglo double
for(int i=0 ; i<salto-1 ; i++)
{
	for(int j=0 ; j<=strlen(texto[i])-1 ; j++ )
	{	
		cout<<"longitud actual: "<<strlen(texto[i])<<endl;
		//Verificando si existe numeros o puntos decimales.
		if(texto[i][j]>='0' && texto[i][j]<='9' || texto[i][j]=='.' || texto[i][j]=='-')
  	  {
					nuevo[fila][col]=texto[i][j];		
					cout<<"Numero encontrado en fila= "<<i<<", col="<<j<<" es: "<<texto[i][j]<<endl;
					col++;
			}
			else
			{
				//En caso cantrario se verificara se existe una coma que determina el final del numero.
				if(texto[i][j]==',')
				{
					total++; //Aumentando el total de numeros a graficar.
					numero[fila]=strtod(nuevo[fila],&cambio);//Realizando conversion char a double
					cout<<"Coma encontrada en fila="<<i<<" col="<<j<<" es: "<<texto[i][j]<<endl;
					fila++; //Aumentando al siguiente numero a buscar
					col=0; //Reiniciando columna
				}
				else
				{
					//Verificando si hay un caracter diferente a espacio.
					if(texto[i][j]!=' ')
					{
						cout<<"No se permiten caractes de fila= "<<i<<" col= "<<j<<" es "<<texto[i][j]<<endl;
						return 1;
					}		
				}		
			}
	}	//Fin for j
} //Fin for i


cout<<endl<<"Numeros encontrados: "<<endl;
for(int i=0 ; i<total ; i++)
{
		cout<<numero[i]+1<<endl;
}

return 0;
}

