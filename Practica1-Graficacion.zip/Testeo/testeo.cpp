////////////////////////////////////////////////////          
// experimentTwoSquares.cpp
// (modifying square.cpp)
// 
// Sumanta Guha.
////////////////////////////////////////////////////

#ifdef __APPLE__
#  include <GL/glew.h>
#  include <GL/freeglut.h>
#  include <OpenGL/glext.h>
#else
#  include <GL/glew.h>
#  include <GL/freeglut.h>
//#  include <GL/glext.h>
#pragma comment(lib, "glew32.lib") 
#endif

#include <cstdio>
#include <stdio.h>

#include <cstdlib>
#include <iostream>
#include <fstream>
#include <cstdio>
#include <string.h>

using namespace std;

double numero[400]; //Arreglo para almacenar los numeros del archivo.
int total=0; //Para realizar un conteo de los numeros encontrados en el archivo.

//Metodo para extraer los valores del archivo Datos.txt
void buscarDatos(void)
{
	ifstream archivo("Datos.txt"); //Nombre del archivo a trabajar
	char texto[400][400]; //Arreglo para almacenar los caracteres del archivo
	int salto=0; //Contador para identificar el numero de lineas
	
	while(!archivo.eof())//Guardando el contenido del archivo en el arreglo linea.
	{ 
		archivo.getline(texto[salto],400);
		cout<<"su tamano es "<<strlen(texto[salto])<<" es "<<texto[salto]<<endl; //Mostrando el contenido
		salto++; //Avanzando a la siguiente fila.
	}
	cout<<"numero de saltos: "<<salto;

	char nuevo[400][400];
	int fila=0; //Para conocer la posición actual de la fila.
	int col=0;  //Para conocer la posición actual de la columna.
	char *cambio; //Para realizar la conversion de la matriz char a arreglo double

	for(int i=0 ; i<salto-1 ; i++)
	{
		for(int j=0 ; j<=strlen(texto[i])-1 ; j++ )
		{	
			//Verificando si existe numeros o puntos decimales.
			if(texto[i][j]>='0' && texto[i][j]<='9' || texto[i][j]=='.' || texto[i][j]=='-')
 		  {
					nuevo[fila][col]=texto[i][j];		
					cout<<"Numero encontrado en fila= "<<i<<", col="<<j<<" es: "<<texto[i][j]<<endl;
					col++;
			}
			else
			{
				//En caso cantrario se verificara se existe una coma que determina el final del numero.
				if(texto[i][j]==',')
				{
					total++; //Aumentando el total de numeros a graficar.
					numero[fila]=strtod(nuevo[fila],&cambio);//Realizando conversion char a double
					fila++; //Aumentando al siguiente numero a buscar
					col=0; //Reiniciando columna
				}
				else
				{
					//Verificando si hay un caracter diferente a espacio.
					if(texto[i][j]!=' ')
					{
						cout<<"Error: Solo está permitido introducir números y ',' en el archivo.";
						exit(0);
					}		
				}		
			}
		}	//Fin for j
	} //Fin for i

if(total%2==0)
{
	cout<<"Error: Se necesitan agregar mas valores.";
}

	cout<<endl<<"Numeros encontrados: "<<endl;
	for(int i=0 ; i<total ; i++)
	{
		cout<<numero[i]+1<<endl;
	}
}



// Routine to draw a bitmap character string.
void writeBitmapString(void *font, char *string)
{  
		char *c;
   for (c = string; *c != '\0'; c++) glutBitmapCharacter(font, *c);
}
  
// Routine to draw a stroke character string.
void writeStrokeString(void *font, char *string)
{  
   char *c;
   for (c = string; *c != '\0'; c++) glutStrokeCharacter(font, *c);
}


// Drawing routine.
void drawScene(void)
{
   glClear(GL_COLOR_BUFFER_BIT);
	
	//Dibujando fondo del escenario
   glColor3f(1.0, 0.80, 0.80);
   glRectf(10.0, 10.0, 790.0, 590.0);

	 //Colocando titulo de la grafica de barras horizontal
	 glColor3f(0.0, 0.0, 0.0);
   glRasterPos3f(360.0, 560.0, 0.0);
   writeBitmapString(GLUT_BITMAP_TIMES_ROMAN_24, "Puntaje ejemplo");

		//Descripcion horizontal
	  glRasterPos3f(390.0, 520.0, 0.0);
   writeBitmapString(GLUT_BITMAP_HELVETICA_18, "Score");

		//Descripciòn vertical
	 glPushMatrix();
   glTranslatef(30.0, 300.0, 0.0);
   glRotatef(90.0, 0.0, 0.0, 1.0);
   glScalef(0.190, 0.140, 0.100);
   writeStrokeString(GLUT_STROKE_ROMAN, "Match");
   glPopMatrix();
	

		//Agregando los valores encima de cada linea vertical de la gráfica horizontal. 
			glColor3f(0.0, 0.0, 0.0);
			glRasterPos3f(80, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "-5.0");
			glRasterPos3f(120, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "-4.5");
			glRasterPos3f(160, 500.0, 0.0);
			writeBitmapString(GLUT_BITMAP_8_BY_13, "-4.0");
			glRasterPos3f(200, 500.0, 0.0);
			writeBitmapString(GLUT_BITMAP_8_BY_13, "-3.5");
			glRasterPos3f(240, 500.0, 0.0);
			writeBitmapString(GLUT_BITMAP_8_BY_13, "-3.0");
			glRasterPos3f(280, 500.0, 0.0);
			writeBitmapString(GLUT_BITMAP_8_BY_13, "-2.5");
			glRasterPos3f(320, 500.0, 0.0);
			writeBitmapString(GLUT_BITMAP_8_BY_13, "-2.0");
			glRasterPos3f(360, 500.0, 0.0);
			writeBitmapString(GLUT_BITMAP_8_BY_13, "-1.5");
			glRasterPos3f(400, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "-1.0");
			glRasterPos3f(440, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "-0.5");
			glRasterPos3f(490, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "0.0");
			glRasterPos3f(530, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "0.5");
			glRasterPos3f(570, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "1.0");
			glRasterPos3f(610, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "1.5");
			glRasterPos3f(650, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "2.0");
			glRasterPos3f(690, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "2.5");
			glRasterPos3f(730, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "3.0");
			glRasterPos3f(770, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "3.5");
			glRasterPos3f(810, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "4.0");
			glRasterPos3f(850, 500.0, 0.0);
   		writeBitmapString(GLUT_BITMAP_8_BY_13, "4.5");

		//Coloreando fondo de las barras
		glColor3f(1.0, 1.0, 1.0);
		glRectf(100.0, 60.0, 760.0, 490.0);
		
 	//Dibujando linea cuadricular
 	glLineWidth(2);
	glColor3f(0.0, 0.0, 0.0);
	glBegin(GL_LINE_LOOP);
     glVertex3f(100.0, 60.0, 0.0);
     glVertex3f(760.0, 60.0, 0.0);
     glVertex3f(760.0, 490.0, 0.0);
     glVertex3f(100.0, 490.0, 0.0);
  glEnd();

			//Lineas verticales transparentes
			glLineWidth(1.5);
			glColor3f(0.7, 0.7, 0.7);
			glBegin(GL_LINES);
				//Generando las lineas verticales apuntando a un valor de la grafica horizontal.
				for(int i=100 ; i<=860 ; i=i+40)
				{		
					glVertex3f(i, 60.0, 0.0);
					glVertex3f(i,490.0,0.0);
				}
				glEnd();

int x1=460;
int x2=475;

	buscarDatos();

		//Generando las barras de puntaje
		for(int i=0 ; i<total ; i++ )
		{
			if((i+1)%2==0)
			{
				glColor3f(0.0, 0.0, 1.0);			
			}
			else
			{
				glColor3f(1.0, 0.0, 0.0);
			}

			if(i==0)
			{
				printf("es: %f \n",numero[i]);
    		glRectf(500.0, 460, (numero[i]*80)+500, 475);	
			}
			else
			{
					x1=x1-20;
					x2=x2-20;
    		glRectf(500.0, x1, (numero[i]*80)+500, x2);				
				printf("es: %f \n",numero[i]);
			}  	
		}

		glColor3f(0.0, 0.0, 0.0);
 glBegin(GL_LINE_LOOP);
       glVertex3f(365.0, 15.0, 0.0);
       glVertex3f(560.0, 15.0, 0.0);
       glVertex3f(560.0, 50.0, 0.0);
       glVertex3f(365.0, 50.0, 0.0);
     glEnd();

		//Descripcion sobre los equipos
		glColor3f(1.0, 0.0, 0.0);
    glRectf(370.0, 30.0, 380.0, 40.0);	

    glColor3f(0.0, 0.0, 0.0);
		glRasterPos3f(385.0, 30.0, 0.0);
   writeBitmapString(GLUT_BITMAP_8_BY_13, "Team 1");

		glColor3f(0.0, 0.0, 1.0);
    glRectf(470.0, 30.0, 480.0, 40.0);	

    glColor3f(0.0, 0.0, 0.0);
		glRasterPos3f(485.0, 30.0, 0.0);
   writeBitmapString(GLUT_BITMAP_8_BY_13, "Team 2");

		//Etiqueta de cada puntaje
   glRasterPos3f(50.0, 400.0, 0.0);
   writeBitmapString(GLUT_BITMAP_8_BY_13, "Match 1");

	 glRasterPos3f(50.0, 360.0, 0.0);
   writeBitmapString(GLUT_BITMAP_8_BY_13, "Match 2");

 glRasterPos3f(50.0, 320.0, 0.0);
   writeBitmapString(GLUT_BITMAP_8_BY_13, "Match 3");

 glRasterPos3f(50.0, 320.0, 0.0);
   writeBitmapString(GLUT_BITMAP_8_BY_13, "Match 4");

 glRasterPos3f(50.0, 300.0, 0.0);
   writeBitmapString(GLUT_BITMAP_8_BY_13, "Match 5");

 glRasterPos3f(50.0, 280.0, 0.0);
   writeBitmapString(GLUT_BITMAP_8_BY_13, "Match 6");

 glRasterPos3f(50.0, 260.0, 0.0);
   writeBitmapString(GLUT_BITMAP_8_BY_13, "Match 7");

 glRasterPos3f(50.0, 240.0, 0.0);
   writeBitmapString(GLUT_BITMAP_8_BY_13, "Match 8");

   glFlush(); 
}

// Initialization routine.
void setup(void) 
{
   glClearColor(0.4,0.4,0.4, 0.0); 
}

// OpenGL window reshape routine.
void resize(int w, int h)
{
   glViewport(0, 0, w, h);
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();
   glOrtho(0.0,850.0, 0.0, 600.0, -1.0, 1.0); 
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

// Keyboard input processing routine.
void keyInput(unsigned char key, int x, int y)
{
   switch(key) 
   {
      case 27:
         exit(0);
         break;
      default:
         break;
   }
}

// Main routine.
int main(int argc, char **argv) 
{
   glutInit(&argc, argv);

   glutInitContextVersion(2, 1);
   glutInitContextProfile(GLUT_COMPATIBILITY_PROFILE);

   glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA); 
   glutInitWindowSize(1000, 600); //Tamaño de la ventana ancho,alto
   glutInitWindowPosition(100, 0); 
   glutCreateWindow("Practica 1");
   glutDisplayFunc(drawScene); 
   glutReshapeFunc(resize);  
   glutKeyboardFunc(keyInput);

   glewExperimental = GL_TRUE;
   glewInit();

   setup(); 
   
   glutMainLoop(); 
}
