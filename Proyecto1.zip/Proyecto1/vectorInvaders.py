#Proyecto No. 1 Vector Invaders
#Integrantes:
#-Andrés Fidel García González
#-Cruz Alejandro Cordova Alanis

from OpenGL.GLUT import *    
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random
import sys
import subprocess # Importante para reproducir sonido
import time # Importante para reproducir sonido

global bgmusica #para la música de fondo
global posicionNave #para el movimiento de la nave principal
global vidas #Representa las vidas del jugador
global Puntuacion #Represental la puntuación del jugador
global banderas, banderasB, banderasC
global disparoYA
global disparoYB
global estado
global puntoCentralX, puntoCentralY #Centro del disparo

#Metodo para la creación de texto.
def escritura(font, string):  
  for char in string:
    glutBitmapCharacter(font,ord(char))


def escritura2(font, string):
   for char in string:
       glutStrokeCharacter(fond,ord(char))


#Metodo para mostrar los mensajes en la terminal
def mostrarMensajes():
    print ("Proyecto 1: Vector Invaders")
    print ("Integrantes:")
    print ("Andrés Fidel García González")
    print ("Cruz Alejandro Cordova Alanis")

#Inicializacion del escenario
def init():
    global posicionNave
    global vidas
    global Puntuacion
    global banderas, banderasB, banderasC
    global disparoYA
    global disparoYB
    global estado
    global puntoCentralX, puntoCentralY

    glClearColor(0.0, 0.0, 0.0, 0.0) 
    posicionNave=0
    vidas=3
    Puntuacion=0
    disparoYA=87.5
    disparoYB=92.5
    estado=False
    puntoCentralX=0.0
    puntoCentralY=0.0

    #Bloques 5x12
    banderas=[[True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True]]
    
    banderasB=[[True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True]]

    banderasC=[[True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True],
              [True, True, True, True, True, True, True, True, True, True, True, True]]
 

def mostrarVida():
    glColor3f(0.9, 0.9, 0.9)
    glRectf(10.0, 15.0, 40, 30.0);
    glColor3f(0.9, 0.2, 0.0)
    glRectf(20.0, 30.0, 30.0, 40.0);
        

#Metodo para mostrar los mensajes en el escenario
def mensajesInterfaz():
    global Puntuacion
    global vidas
    maxPuntuacion=99999999

    glColor3f(1.0, 1.0, 0.0) 
    glLineWidth(2.0);
    glBegin(GL_LINES);
    glVertex3f(0.0, 60.0, 0.0);
    glVertex3f(400.0, 60.0, 0.0);
    glEnd();

    if vidas>1:
        mostrarVida()
        if vidas>2:
            glPushMatrix()
            glTranslatef(40, 0.0, 0.0)
            mostrarVida()
            glPopMatrix()
   
    glColor3f(0.9, 0.3, 0.0)
    glRasterPos3f(140.0, 40.0, 0.0)
    escritura(GLUT_BITMAP_8_BY_13,"JUGADOR: ")

    glColor3f(1.0, 1.0, 0.0)
    glRasterPos3f(140.0, 20.0, 0.0)
    escritura(GLUT_BITMAP_9_BY_15,"AHEGAO")

    if Puntuacion>maxPuntuacion:
        Puntuacion=maxPuntuacion

    strPuntuacion = str(Puntuacion)
    lenPuntuacion = len(strPuntuacion)
    printPuntuacion = (8-lenPuntuacion)*'0'+strPuntuacion
    #8 significa el tamaño de la puntuacion "00000000"

    glColor3f(1.0, 1.0, 0.0)
    glRasterPos3f(280.0, 40.0, 0.0)
    escritura(GLUT_BITMAP_8_BY_13,"HI-SCORE")
    glRasterPos3f(280.0, 20.0, 0.0)
    escritura(GLUT_BITMAP_9_BY_15,printPuntuacion)
   

#Dibujado de naves
def DibujarNavePrincipal():
    global posicionNave
    global disparoYA, disparoYB
    global puntoCentralX, puntoCentralY
    glColor3f(0.9, 0.2, 0.0)
    glRectf(posicionNave+10.0, 85.0, posicionNave+20.0, 95.0);
    glColor3f(0.9, 0.9, 0.9)
    glRectf(posicionNave, 70.0, posicionNave+30, 85.0);
    
    #Dibujando disparo
    glColor3f(1.0, 1.0, 0.0)
    glRectf(posicionNave+12.5, disparoYA, posicionNave+17.5, disparoYB);
    #Guardando las coordenadas del punto central del disparo.
    puntoCentralX=posicionNave+15
    puntoCentralY=disparoYA+2.5
    glutPostRedisplay()
    

def EnemigoDebil():
    pass
    #aquí se dibuja la nave de más abajo

def EnemigoNormal():
    pass
    #Aquí se dibuja la nave de medio

def EnemigoFuerte():
    pass
    #Aqui se dibuja la nave de más arriba

#Metodo para dibujar las defensas en el escenario.
def dibujarDefesa():
    global banderas, banderasB, banderasC, estado
    global puntoCentralX, puntoCentralY
    global disparoYA, disparoYB
    x1=40
    y1=110
    x2=45
    y2=115

    #Defensa 1
    glColor3f(1.0, 0.0, 0.0);
    for i in range(5):
        for j in range(12):
            print ("puntoCentralX: ",puntoCentralX, " puntoCentralY: ",puntoCentralY, "punto Y= ",y1)
            if puntoCentralX >= x1 and puntoCentralX <= x2 and puntoCentralY >= y1 and banderas[i][j]==True:
                estado=False
                banderas[i][j]=False
                disparoYA=87.5
                disparoYB=92.5
            
            #Limitando el disparo
            if puntoCentralY >= 650:
                estado=False
                disparoYA=87.5
                disparoYB=92.5
                

            if banderas[i][j] == True:
                glRectf(x1, y1, x2, y2);
            x1=x1+5
            x2=x2+5
            print ("i: ",i," j: ",j)
            print ("Bandera: ",banderas[i][j])
            if j == 11:
                y1=y1+5
                y2=y2+5
                x1=40
                x2=45

    x1=170
    y1=110
    x2=175
    y2=115

    #Defensa 2
    glColor3f(1.0, 0.0, 0.0);
    for i in range(5):
        for j in range(12):
            print ("puntoCentralX: ",puntoCentralX, " puntoCentralY: ",puntoCentralY, "punto Y= ",y1)
            if puntoCentralX >= x1 and puntoCentralX <= x2 and puntoCentralY >= y1 and banderasB[i][j]==True:
                estado=False
                banderasB[i][j]=False
                disparoYA=87.5
                disparoYB=92.5
               
            #Limitando el disparo
            if puntoCentralY >= 650:
                estado=False
                disparoYA=87.5
                disparoYB=92.5

            if banderasB[i][j] == True:
                glRectf(x1, y1, x2, y2);
            x1=x1+5
            x2=x2+5
            print ("i: ",i," j: ",j)
            print ("Bandera: ",banderasB[i][j])
            if j == 11:
                y1=y1+5
                y2=y2+5
                x1=170
                x2=175

    x1=300
    y1=110
    x2=305
    y2=115

    #Defensa 2
    glColor3f(1.0, 0.0, 0.0);
    for i in range(5):
        for j in range(12):
            print ("puntoCentralX: ",puntoCentralX, " puntoCentralY: ",puntoCentralY, "punto Y= ",y1)
            if puntoCentralX >= x1 and puntoCentralX <= x2 and puntoCentralY >= y1 and banderasC[i][j]==True:
                estado=False
                banderasC[i][j]=False
                disparoYA=87.5
                disparoYB=92.5
               
            #Limitando el disparo
            if puntoCentralY >= 650:
                estado=False
                disparoYA=87.5
                disparoYB=92.5

            if banderasC[i][j] == True:
                glRectf(x1, y1, x2, y2);
            x1=x1+5
            x2=x2+5
            print ("i: ",i," j: ",j)
            print ("Bandera: ",banderasC[i][j])
            if j == 11:
                y1=y1+5
                y2=y2+5
                x1=300
                x2=305

def disparar():
    global disparoYA, disparoYB
    disparoYA += 5
    disparoYB += 5
    
    
    

#Ajustes del escenario.
def redimensionar(w, h): 
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, 400.0, 0.0, 650.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity()

#Mostrando el escenario del juego
def mostrarEscenario():
    glClear(GL_COLOR_BUFFER_BIT)

    mensajesInterfaz()

    glColor3f(0.0, 0.0, 0.0)
    DibujarNavePrincipal()

    dibujarDefesa()

    if estado == True:
        disparar()
        glutPostRedisplay()
    
    
    glFlush()

#Finalizando la musica al terminar el programa.
def finalizar():
    global bgmusica
    print (" Termino Ventana")  
    bgmusica.terminate()
    sys.exit(0)

#Metodo para las funciones del teclado.
def teclado(key, x, y):
    global Puntuacion
    global vidas
    global posicionNave
    global bgmusica  # Tambien con 
    global estado

    if key == b'a': # izquierda
        if posicionNave>0:
            posicionNave-=2
            glutPostRedisplay();
    
    if key == b'\033': 
        bgmusica.kill()
        sys.exit(0) 

    if key == b'd':
        if posicionNave<400-30:
            posicionNave+=2
            glutPostRedisplay()

    #Base para cuando el jugador pierde una vida
    if key == b' ':
        vidas=vidas-1
        posicionNave=0
        glutPostRedisplay()

    if key == b'+':
        Puntuacion += 1
        glutPostRedisplay()

    if key == b'k':
        estado=True
        fuego = subprocess.Popen(['mplayer', './Laser.mp3'])
        glutPostRedisplay()

#Metodo principal main
def main():
    global bgmusica
    bgmusica = subprocess.Popen(['mplayer', './bgbattletoad.mp3', '-loop','0','&'])
    mostrarMensajes()
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB)
    glutInitWindowPosition(450, 100)
    glutInitWindowSize(400, 560)
    glutCreateWindow("Proyecto No.1 , Vector Ivaders")
    glutReshapeFunc(redimensionar)
    glutDisplayFunc(mostrarEscenario)
    glutKeyboardFunc(teclado)

    glutWMCloseFunc(finalizar) 

    init()

    glutMainLoop()
  
main()