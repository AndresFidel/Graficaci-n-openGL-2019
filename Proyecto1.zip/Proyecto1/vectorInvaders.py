# Ejecucion:
# python3 HolaOpenGL.py

from OpenGL.GLUT import *       # GL Utilities Toolkit
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random
import sys
import subprocess # Importante para reproducir sonido
import time # Importante para reproducir sonido

global bgmusica

def mostrarMensajes():
    print ("Proyecto 1: Vector Invaders")
    print ("Integrantes:")
    print ("Andrés Fidel García González")
    print ("Cruz Alejandro Cordova Alanis")

def init():
    global numVertices # Le dices al python que estas modicando una variable global y no una local de nombre numvertices
    glClearColor(0.0, 0.0, 0.0, 0.0) 
    numVertices=5

def redimensionar(w, h): 
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-100.0, 100.0, 0.0, 100.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity()
   
def teclado(key, x, y):
    global bgmusica  # Tambien con 
    if key == b'a': # izquierda
        izquierda = subprocess.Popen(['aplay', './Squish.wav'])
        glutPostRedisplay();
    
    if key == b'\033': 
        bgmusica.kill() # Terminar el proceso del sonido
        sys.exit(0) # Le violan el segmento

def mostrarEscenario():
    glClear(GL_COLOR_BUFFER_BIT)

    glColor3f(0.0, 0.0, 0.0)
    
    glFlush()

def finalizar():
    global bgmusica
    print (" Termino Ventana")	
    bgmusica.terminate() # Terminar proceso
    sys.exit(0)


def main():
    global bgmusica
    bgmusica = subprocess.Popen(['mplayer', './bgbattletoad.mp3', '-loop','0','&'])
    mostrarMensajes()
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB)
    glutInitWindowPosition(100, 100)
    glutInitWindowSize(500, 500)
    glutCreateWindow("Proyecto No.1 , Vector Ivaders")
    glutReshapeFunc(redimensionar)
    glutDisplayFunc(mostrarEscenario)
    glutKeyboardFunc(teclado)

    glutWMCloseFunc(finalizar) # Cuando la ventana se cierra..	

    init()

    glutMainLoop()
	
 
main()