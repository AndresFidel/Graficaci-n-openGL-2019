#Proyecto No. 1 Vector Invaders
#Integrantes:
#-Andrés Fidel García González
#-Cruz Alejandro Cordova Alanis

from OpenGL.GLUT import *    
from OpenGL.GL import *
from OpenGL.GLU import *
import math
import random
import sys
import subprocess # Importante para reproducir sonido
import time # Importante para reproducir sonido

global bgmusica #para la música de fondo

#Metodo para la creación de texto.
def escritura(font, string):  
  for char in string:
    glutBitmapCharacter(font,ord(char))


def escritura2(font, string):
   for char in string:
       glutStrokeCharacter(fond,ord(char))


#Metodo para mostrar los mensajes en la terminal
def mostrarMensajes():
    print ("Proyecto 1: Vector Invaders")
    print ("Integrantes:")
    print ("Andrés Fidel García González")
    print ("Cruz Alejandro Cordova Alanis")

def mostrarVida():
    glColor3f(0.9, 0.9, 0.9)
    glRectf(10.0, 15.0, 40, 30.0);
    glColor3f(0.9, 0.2, 0.0)
    glRectf(20.0, 30.0, 30.0, 40.0);
        

#Metodo para mostrar los mensajes en el escenario
def mensajesInterfaz():
   glColor3f(1.0, 1.0, 0.0) 
   glLineWidth(2.0);
   glBegin(GL_LINES);
   glVertex3f(0.0, 60.0, 0.0);
   glVertex3f(400.0, 60.0, 0.0);
   glEnd();

   mostrarVida()
      
   glPushMatrix();
   glTranslatef(40, 0.0, 0.0);
   mostrarVida()
   glPopMatrix();

   glPushMatrix();
   glTranslatef(80, 0.0, 0.0);
   mostrarVida()
   glPopMatrix();
   
   glColor3f(1.0, 1.0, 0.0)
   glRasterPos3f(140.0, 40.0, 0.0)
   escritura(GLUT_BITMAP_8_BY_13,"JUGADOR: ")

   glColor3f(1.0, 1.0, 0.0)
   glRasterPos3f(280.0, 40.0, 0.0)
   escritura(GLUT_BITMAP_8_BY_13,"HI-SCORE")
   glRasterPos3f(280.0, 20.0, 0.0)
   escritura(GLUT_BITMAP_8_BY_13,"00000000")
   

#Inicializacion del escenario
def init():
    glClearColor(0.0, 0.0, 0.0, 0.0) 

#Ajustes del escenario.
def redimensionar(w, h): 
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, 400.0, 0.0, 650.0, -1.0, 1.0);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity()

#Metodo para las funciones del teclado.
def teclado(key, x, y):
    global bgmusica  # Tambien con 
    if key == b'a': # izquierda
        #izquierda = subprocess.Popen(['aplay', './Squish.wav'])
        glutPostRedisplay();
    
    if key == b'\033': 
        #bgmusica.kill()
        sys.exit(0) 

#Mostrando el escenario del juego
def mostrarEscenario():
    glClear(GL_COLOR_BUFFER_BIT)

    mensajesInterfaz()

    glColor3f(0.0, 0.0, 0.0)

    
    
    glFlush()

#Finalizando la musica al terminar el programa.
def finalizar():
    global bgmusica
    print (" Termino Ventana")	
    bgmusica.terminate()
    sys.exit(0)

#Metodo principal main
def main():
    global bgmusica
    #bgmusica = subprocess.Popen(['mplayer', './bgbattletoad.mp3', '-loop','0','&'])
    mostrarMensajes()
    glutInit(sys.argv)
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB)
    glutInitWindowPosition(450, 100)
    glutInitWindowSize(400, 560)
    glutCreateWindow("Proyecto No.1 , Vector Ivaders")
    glutReshapeFunc(redimensionar)
    glutDisplayFunc(mostrarEscenario)
    glutKeyboardFunc(teclado)

    #glutWMCloseFunc(finalizar)	

    init()

    glutMainLoop()
	
main()